
const runStart = ()=>{
    console.log('onStart')
}
const runUpdate = () => {
    console.log('onUpdate')
}
const runComplete = () => {
    console.log('onComplete')
}

const tl = gsap.timeline({
    duration:1,
    paused:true,
    onStart:runStart,
    onUpdate:runUpdate,
    onComplete:runComplete

});



tl
.from
(    'body',
{
    backgroundColor:'#fff',
    duration:1.7,
    ease:'none'
})

.fromTo('h1',{opacity:0,y:-20}, {opacity:1,y:0,duration:0.7,ease:'power2.inOut'},'-=1')

.fromTo('p',{opacity:0}, {opacity:1,ease:'power2.inOut'},'-=0.5')
.fromTo('img',{opacity:0},{opacity:1,ease:'power2.inOut'})
.fromTo('h2',{opacity:0},{opacity:1,ease:'power2.inOut'})
.fromTo('ul li',{opacity:0,x:100},{opacity:1,stagger:0.1,ease:'power2.inOut',x:0},)

const playButton = document.querySelector('#btnPlay')
const pauseButton = document.querySelector('#btnPause')
const resumeButton = document.querySelector('#btnResume')
const reverseButton = document.querySelector('#btnReverse')
const speedUpButton = document.querySelector('#btnSpeedUp')
const slowDownButton = document.querySelector('#btnSlowDown')
const seekButton = document.querySelector('#btnSeek')
const progressButton = document.querySelector('#btnProgress')
const restartButton = document.querySelector('#btnRestart')


playButton.addEventListener('click',() => {
    tl.play()
})
pauseButton.addEventListener('click', () => {
    tl.pause()
})
resumeButton.addEventListener('click',() => {
    tl.resume()
})
reverseButton.addEventListener('click', () => { 
    tl.reverse()
})

speedUpButton.addEventListener('click', () => {
    tl.scale(2)
})

slowDownButton.addEventListener('click',() => {
    tl.scale(0.5)
})

seekButton.addEventListener('click',() => {
    tl.seek(2)
})
progressButton.addEventListener('click',() => {
    tl.progress(0.5)
})
restartButton.addEventListener('click', () => {
    tl.restart()
})